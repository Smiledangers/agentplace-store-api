# 商店庫存與訂單助手

Node.js 22 以上，無外部套件。所有專案檔案放在 `E:\FieldPro\store-agent-demo`。

## 安裝與啟動（PowerShell）

```powershell
Set-Location E:\FieldPro\store-agent-demo
Copy-Item .env.example .env
# 產生本機專用 token，不輸出秘密；寫入被 Git 排除的 .env。
node -e "const fs=require('node:fs'); const key=require('node:crypto').randomBytes(32).toString('hex'); fs.writeFileSync('.env','STORE_API_KEY='+key+'\nHOST=127.0.0.1\nPORT=43187\n');"
npm start
```

不需要執行 npm install。未設定至少 32 字元的 token 時，服務拒絕啟動。

另開 PowerShell 查詢：

```powershell
Set-Location E:\FieldPro\store-agent-demo
$storeToken = (Get-Content .env | Where-Object { $_ -like 'STORE_API_KEY=*' }) -replace '^STORE_API_KEY=', ''
$storeHeaders = @{ Authorization = "Bearer $storeToken" }
Invoke-RestMethod http://127.0.0.1:43187/api/products/P001/inventory -Headers $storeHeaders
Invoke-RestMethod http://127.0.0.1:43187/api/orders/O004/status -Headers $storeHeaders
Invoke-RestMethod http://127.0.0.1:43187/api/products/P004/inventory -Headers $storeHeaders
```

依序會得到無線滑鼠庫存 25、訂單 shipped、藍牙耳機庫存 0 且 available=false。

## API 契約

- `GET /api/products/{productId}/inventory`：P001–P010 為範例商品。
- `GET /api/orders/{orderId}/status`：O001–O010 為範例訂單。
- ID 必須為大寫 P 或 O 加三位數，排除 000；有效格式但不存在（例如 P999）回傳 404。
- 成功：`{"data":{...}}`。失敗：`{"error":{"code":"...","message":"..."}}`。
- 400：ID 無效、缺 ID、未知查詢參數；401：缺少／錯誤 token；404：資料或路由不存在；405：寫入方法不受支援。
- `/health` 與 `/openapi.json` 公開，不回傳秘密。其餘路由一律先檢查 Bearer token。
- 請求只允許 GET，資料從 JSON 載入，無寫入介面。回應禁止快取。完整規格在 `openapi.json`。

這是使用虛構資料的內部展示：共用服務 token 代表 Agent 的唯讀服務權限。沒有實作個別消費者登入或訂單擁有權授權。正式商店若使用真實訂單，需加入使用者驗證與訂單擁有權檢查。

## 重跑測試

```powershell
node --test test/api.test.js
node scripts/record-evidence.js
```

`evidence/api-results.json` 保留 50 個情境的實際 HTTP 狀態與回應。測試另包含設定不足時拒絕啟動；涵蓋全部 20 筆資料、零庫存、不存在資料、無效 ID、授權拒絕與拒絕寫入。測試使用隨機／測試專用 token，不含正式憑證。Agent 對話驗證另見 `docs/agent-tests.json`，API 通過不代表 Agent 通過。

## 部署與 Agentplace

依 `docs/AGENTPLACE.md` 操作。雲端 Agent 無法存取本機 127.0.0.1。必須將此服務部署到具有公開 HTTPS 的主機，或採用平台實際支援且可安全存放憑證的同等方式。

`Dockerfile` 可選用；主機需注入 `STORE_API_KEY`，對外由 HTTPS 反向代理終結 TLS。沒有設定任何付費服務。不要將 .env、token 放到儲存庫、前端、聊天內容或提交信。
