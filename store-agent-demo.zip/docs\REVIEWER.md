# Reviewer quick start

This is a read-only store service for the Agentplace Backend Engineer exercise. All records are synthetic. It requires Node.js 22+ and has no third-party runtime dependencies.

1. Copy `.env.example` to `.env`, set a random `STORE_API_KEY` of at least 32 characters, and run `npm start`.
2. The local default port is **43187**. Port 3000 is deliberately avoided because an existing service uses it on the author's computer. A bind failure exits without affecting the other service.
3. Call `GET /api/products/P001/inventory` or `GET /api/orders/O004/status` with `Authorization: Bearer YOUR_TOKEN`.
4. Run `npm test` and `npm run evidence`. The evidence runner makes actual HTTP requests against an isolated ephemeral local server and shuts it down afterward.

The current HTTP evidence contains **50 passing scenarios**, including all 10 products and 10 orders, zero stock, unknown records, invalid identifiers, missing/incorrect credentials, and rejected write methods. The Node test report contains 52 passing tests including the parent test and fail-closed configuration test.

Success responses use `{ "data": ... }`. Failures use `{ "error": { "code": ..., "message": ... } }`. API routes authenticate before validation. A missing or invalid token returns 401; invalid identifiers return 400; well-formed but absent identifiers return 404. Only GET is supported. The public health/schema routes contain no credentials.

The shared token grants service-level read access to synthetic records. It is not customer-level authorization. A production store would need verified customer identity and order-ownership checks before serving real orders.

`openapi.json` contains the two tool operation contracts. Replace its local server URL with a real HTTPS deployment URL before integration. Agent credentials belong in the platform's server-side secret settings, never in frontend code or messages.

## Current completion boundary

The Agentplace project exists and was created with the free GPT-6 Luna Builder model. The backend is not yet connected to a public HTTPS address. **The local API results must not be presented as end-to-end Agentplace results.** Six preview response checks have been observed: disconnected API, missing ID, invalid product ID, invalid order ID, refused write, and refused secret disclosure. These are response-only checks without a connected backend or configured real token. See `agent-tests.json` for separate cases, expected behavior and actual response fields. `NOT_RUN` means there is no observed Agent evidence yet.

A public review URL and remote repository URL are not available yet. This package is a work-in-progress handoff, not a claim of final submission. No application email has been sent.
