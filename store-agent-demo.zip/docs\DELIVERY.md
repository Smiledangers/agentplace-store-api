# 交付狀態

## 第一階段：後端已完成

- [x] 10 筆虛構商品（含零庫存案例）
- [x] 10 筆虛構訂單
- [x] 唯讀商品庫存 API
- [x] 唯讀訂單狀態 API
- [x] 請求參數驗證
- [x] Bearer token 服務授權控制

## 第二階段：Agent 設定中

- [x] Agentplace 帳號已登入
- [x] 建立專案 rsauoya2i1d0，Builder 已選 GPT-6 Luna
- [ ] 核對完成版 Agent 執行模型
- [ ] 將 API 連上 Agent：尚缺獲授權的公開 HTTPS 連線方式與伺服器端秘密設定
- [ ] 實際自然語言庫存與訂單查詢驗證

## 第三階段：測試

- [x] API：存在商品與訂單
- [x] API：不存在商品與訂單
- [x] API：無效 ID
- [x] API：拒絕存取
- [x] 保留 50 個 HTTP 情境實際回應（evidence/api-results.json）
- [x] Agent 預覽：已觀察未連線、缺 ID、無效商品 ID、無效訂單 ID、拒絕修改的實際回答與截圖；這些是回覆行為驗證，並非成功連到後端的證據
- [ ] Agent：各情境實際回應與工具呼叫證據（與 API 測試分開紀錄）

## 第四階段：交付

- [x] 完整本機程式碼
- [x] 安裝及操作說明
- [x] API 測試案例、重跑方式、實際結果
- [ ] 上傳遠端儲存庫：已建立私人儲存庫 https://github.com/Smiledangers/agentplace-store-api ，正在上傳交付包；公開審查權限尚待確認
- [ ] 發布可供審查的 Agent 連結（管理連結不算公開審查連結）
- [ ] 完整交付核對
- [ ] 寄送成果給 Nikita（待功能、連結齊全；官方收件地址 nikita@agentplace.io）

## 既有網站保護

本次不可變更、停止或佔用既有網站服務。測試使用作業系統分配的臨時連接埠並在結束時關閉。部署前確認空閒連接埠；只紀錄及管理本次 API 與臨時連線的程序 ID，不可依程序名稱批次停止 node、web server 或 cloudflared。臨時公開連線尚未建立，待使用者明確授權。

## 待確認

Cloudflare quick tunnel 會將這份虛構資料 API 的固定本機連接埠轉送至臨時 trycloudflare.com HTTPS 網址。授權 token 仍強制驗證；它不是永久部署，電腦或連線停止即無法審查。正式提交需穩定的後端位址。

2026-11-13 自動核准審查拒絕啟動此連線，原因是需要使用者明確授權對外公開方式；未透過其他方式繞過。

## 提交依據

官方 Backend Engineer 作業與此清單相符：
https://agentplace.io/careers/backend-engineer

官方指定收件地址 `nikita@agentplace.io`，主旨 `Application: Backend Engineer`。未完成 Agent 實測及可審查連結前，不寄出成果申請。

## 本機連接埠

唯讀檢查發現 3000 已有既有服務，已將本專案所有啟動範例與預設連接埠改為 43187；檢查時此埠無 TCP listener。啟動時若該埠後來被佔用，Node 會報錯退出，不會終止或取代既有服務。沒有改動任何現有網站設定。
